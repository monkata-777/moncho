const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const DISCORD_WEBHOOK_URL = process.env.DISCORD_WEBHOOK_URL || "";
const DATA_FILE = path.join(__dirname, "site-data.json");

if (!ADMIN_PASSWORD) {
  console.error("Set ADMIN_PASSWORD before starting the server.");
  process.exit(1);
}

app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));

function readData() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
  catch { return { name: "Добавяне на приятел", description: "Свържи се с общността", image: "" }; }
}
function writeData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}
function authorized(req) {
  return req.headers.authorization === `Bearer ${ADMIN_PASSWORD}`;
}

app.get("/api/profile", (req, res) => res.json(readData()));

app.post("/api/admin/login", (req, res) => {
  if (req.body.password !== ADMIN_PASSWORD) return res.status(401).json({ error: "Грешна парола." });
  res.json({ token: ADMIN_PASSWORD });
});

app.put("/api/admin/profile", (req, res) => {
  if (!authorized(req)) return res.status(401).json({ error: "Нямате достъп." });
  const { name, description, image } = req.body || {};
  if (typeof name !== "string" || typeof description !== "string" || typeof image !== "string")
    return res.status(400).json({ error: "Невалидни данни." });
  if (name.length > 80 || description.length > 240 || image.length > 1500000)
    return res.status(413).json({ error: "Съдържанието е твърде голямо." });
  if (image && !image.startsWith("data:image/")) return res.status(400).json({ error: "Качи валидно изображение." });
  const data = { name: name.trim(), description: description.trim(), image };
  writeData(data);
  res.json({ ok: true });
});

// Anonymous opt-in event only: never accepts or forwards phone numbers.
app.post("/api/register-interest", async (req, res) => {
  if (req.body?.consent !== true) return res.status(400).json({ error: "Необходимо е съгласие." });
  if (DISCORD_WEBHOOK_URL) {
    try {
      await fetch(DISCORD_WEBHOOK_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: "Ново доброволно записване за интерес (без лични данни)." })
      });
    } catch (e) { console.error("Discord notification failed:", e.message); }
  }
  res.json({ ok: true });
});

app.get("/admin", (req, res) => res.sendFile(path.join(__dirname, "public", "admin.html")));
app.listen(PORT, () => console.log(`Site running on port ${PORT}`));
